<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Map_tiles" tilewidth="64" tileheight="64" tilecount="144" columns="12">
 <image source="../../../../Downloads/Map_tiles.png" width="768" height="768"/>
</tileset>
