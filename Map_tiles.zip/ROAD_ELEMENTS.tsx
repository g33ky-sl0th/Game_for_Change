<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ROAD_ELEMENTS" tilewidth="64" tileheight="64" tilecount="5766" columns="93">
 <image source="ROAD_ELEMENTS.jpg" width="6000" height="4000"/>
</tileset>
