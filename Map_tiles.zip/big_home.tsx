<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="big_home" tilewidth="64" tileheight="64" tilecount="210" columns="15">
 <image source="big_home.jpg" width="1000" height="950"/>
</tileset>
