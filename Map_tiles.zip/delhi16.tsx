<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="delhi16" tilewidth="64" tileheight="64" tilecount="54" columns="9">
 <image source="delhi16.jpg" width="612" height="408"/>
</tileset>
