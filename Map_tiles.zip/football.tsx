<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="football" tilewidth="64" tileheight="64" tilecount="180" columns="15">
 <image source="../../../../Downloads/football.jpg" width="1000" height="780"/>
</tileset>
