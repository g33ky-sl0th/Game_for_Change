<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="ground" tilewidth="64" tileheight="64" tilecount="64" columns="8">
 <image source="../../../../Downloads/ground.jpeg" width="512" height="512"/>
</tileset>
