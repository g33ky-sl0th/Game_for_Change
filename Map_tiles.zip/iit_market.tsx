<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="iit_market" tilewidth="64" tileheight="64" tilecount="336" columns="28">
 <image source="../../../../Downloads/iit_market.png" width="1818" height="800"/>
</tileset>
