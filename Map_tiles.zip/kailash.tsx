<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="kailash" tilewidth="64" tileheight="64" tilecount="42" columns="7">
 <image source="kailash.jpg" width="473" height="408"/>
</tileset>
