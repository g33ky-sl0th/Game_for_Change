<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="lecture_hall" tilewidth="64" tileheight="64" tilecount="400" columns="25">
 <image source="lecture_hall.jpg" width="1600" height="1024"/>
</tileset>
