<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="rni" tilewidth="64" tileheight="64" tilecount="629" columns="37">
 <image source="rni.jpg" width="2400" height="1124"/>
</tileset>
