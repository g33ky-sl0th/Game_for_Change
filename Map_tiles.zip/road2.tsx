<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="road2" tilewidth="64" tileheight="64" tilecount="88" columns="11">
 <image source="../../../../Downloads/road2.jpg" width="736" height="574"/>
</tileset>
