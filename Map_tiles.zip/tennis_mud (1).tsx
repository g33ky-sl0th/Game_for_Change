<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tennis_mud (1)" tilewidth="64" tileheight="64" tilecount="50" columns="10">
 <image source="../../../../Downloads/tennis_mud (1).jpg" width="640" height="320"/>
</tileset>
