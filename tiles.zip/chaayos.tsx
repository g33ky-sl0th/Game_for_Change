<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="chaayos" tilewidth="64" tileheight="64" tilecount="192" columns="16">
 <image source="../../../../Downloads/chaayos.png" width="1024" height="768"/>
</tileset>
