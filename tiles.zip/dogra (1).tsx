<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="dogra (1)" tilewidth="64" tileheight="64" tilecount="180" columns="15">
 <image source="../../../../Downloads/dogra (1).jpg" width="1000" height="800"/>
</tileset>
