<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="hospital (1)" tilewidth="64" tileheight="64" tilecount="1024" columns="32">
 <image source="../../../../Downloads/hospital (1).jpg" width="2048" height="2048"/>
</tileset>
