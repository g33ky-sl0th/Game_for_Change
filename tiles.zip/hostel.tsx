<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="hostel" tilewidth="64" tileheight="64" tilecount="100" columns="10">
 <image source="../../../../Downloads/hostel.jpg" width="640" height="640"/>
</tileset>
