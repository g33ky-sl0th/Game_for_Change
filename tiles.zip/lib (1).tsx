<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="lib (1)" tilewidth="64" tileheight="64" tilecount="88" columns="11">
 <image source="../../../../Downloads/lib (1).jpg" width="720" height="512"/>
</tileset>
