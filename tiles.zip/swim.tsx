<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="swim" tilewidth="64" tileheight="64" tilecount="405" columns="27">
 <image source="../../../../Downloads/swim.jpg" width="1744" height="980"/>
</tileset>
