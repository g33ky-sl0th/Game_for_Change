<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tennis_mud" tilewidth="64" tileheight="64" tilecount="80" columns="10">
 <image source="../../../../Downloads/tennis_mud.png" width="640" height="512"/>
</tileset>
