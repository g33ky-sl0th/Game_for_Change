<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="volley" tilewidth="64" tileheight="64" tilecount="70" columns="10">
 <image source="volley.jpg" width="700" height="490"/>
</tileset>
